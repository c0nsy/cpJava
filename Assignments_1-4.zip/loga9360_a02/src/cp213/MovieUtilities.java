package cp213;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

/**
 * Utilities for working with Movie objects.
 *
 * @author David Brown
 * @version 2020-10-01
 */
public class MovieUtilities {

    /**
     * Counts the number of movies in each genre given in Movie.GENRES.
     *
     * @param movies
     *            list of movies
     * @return
     */
    public static int[] genreCounts(final ArrayList<Movie> movies) {

    // your code here

    }

    /**
     * Creates a Movie object by requesting data from a user.
     *
     * @param keyboard
     *            a keyboard Scanner
     * @return a Movie object
     */
    public static Movie getMovie(final Scanner keyboard) {

    System.out.println("Enter the title of a movie");
    
    String title = keyboard.nextLine();
    
    System.out.println("Enter the year of the movie");
    
    int year = keyboard.nextInt();
    
    System.out.println("Enter the directors name");
    
    String dir = keyboard.nextLine();
    
    System.out.println("Enter the rating of the movie");
    
    double rating = keyboard.nextDouble();
    
    System.out.println("Enter the genre");
    
    }

    /**
     * Creates a list of Movies whose list of genres include genre.
     *
     * @param movies
     *            list of movies
     * @param genre
     *            genre to compare against
     * @return list of movies for genre
     */
    public static ArrayList<Movie> getByGenre(final ArrayList<Movie> movies,
	    final int genre) {
	final ArrayList<Movie> gMovies = new ArrayList<>();

    // your code here

	return gMovies;
    }

    /**
     * Creates a list of Movies whose list of genres include all the genre codes
     * in genres.
     *
     * @param movies
     *            list of movies
     * @param genres
     *            genres list to compare against
     * @return list of movies for genres
     */
    public static ArrayList<Movie> getByGenres(final ArrayList<Movie> movies,
	    final Integer[] genres) {
	final ArrayList<Movie> gMovies = new ArrayList<>();

    // your code here

	return gMovies;
    }

    /**
     * Creates a list of Movies whose ratings are equal to or higher than
     * rating.
     *
     * @param movies
     *            list of movies
     * @param rating
     *            to compare against
     * @return list of movies for rating
     */
    public static ArrayList<Movie> getByRating(final ArrayList<Movie> movies,
	    final double rating) {
	final ArrayList<Movie> rMovies = new ArrayList<>();

    // your code here

	return rMovies;
    }

    /**
     * Creates a list of Movies from a particular year.
     *
     * @param movies
     *            list of movies
     * @param year
     *            year to search for
     * @return list of movies for year
     */
    public static ArrayList<Movie> getByYear(final ArrayList<Movie> movies,
	    final int year) {
	final ArrayList<Movie> yMovies = new ArrayList<>();

    // your code here

	return yMovies;
    }

    /**
     * Testing.
     *
     * @param args
     *            Unused
     * @throws FileNotFoundException
     */
    public static void main(final String[] args) throws FileNotFoundException {

    // your code here

    }

    /**
     * Asks a user to select genres from a list of genres and returns an integer
     * list of the genres chosen.
     *
     * @return
     */
    public static Integer[] readGenres(final Scanner keyboard) {
	final ArrayList<Integer> genres = new ArrayList<>();

    // your code here

	return genres.toArray(new Integer[1]);
    }

    /**
     * Creates and returns a Movie object from a line of formatted string data.
     *
     * @param line
     *            a vertical bar-delimited line of movie data in the format
     *            title|year|director|rating|genres
     * @return the data from line as a Movie object
     */
    public static Movie readMovie(final String line) {

    // your code here

    }

    /**
     * Reads a list of Movies from a file.
     *
     * @param file
     *            The file to read.
     * @return A list of Movie objects.
     * @throws FileNotFoundException
     */
    public static ArrayList<Movie> readMovies(final File file)
	    throws FileNotFoundException {
	final ArrayList<Movie> movies = new ArrayList<>();

    // your code here

	return movies;
    }

    /**
     * Writes the contents of movies to fv. Overwrites or creates a new file of
     * Movie objects converted to strings.
     *
     * @param fv
     * @param movies
     * @throws FileNotFoundException
     */
    public static void writeMovies(final File file, final Movie[] movies)
	    throws FileNotFoundException {

    // your code here

    }

}
