package cp213;

import java.util.Scanner;

public class A01 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		boolean result;
		boolean result2;
		boolean result3;
		String pigLatin = "";
		int year;
		String s1 = new String ("123") ;
	    String s2 = new String ("123") ;
	    System.out.print ( (s1==s2 ) ); 
		System.out.print("Enter a string:");
		
		String s = input.next();
		s = s.replaceAll("\\s", "");
		s = s.replaceAll("\\d", "");
		s = s.toLowerCase();
		result = isPalindrome(s);
		
		if (result == true){
			System.out.println("'" + s + "'" + " is a palindrome.");
		}
		else {
			System.out.println("'" + s + "'" + " is not a palindrome.");
		}
		
		System.out.print("Enter variable name:");
		
		String name = input.next();
		result2 = isValid(name);
		
		if (result2 == true) {
			System.out.println("'" + name + "'" + " is a valid Java name.");
		}
		
		else {
			System.out.println("'"+name+"'"+" is not a valid Java name.");
		}
		
		
		System.out.println("Word: ");
		
		String word = input.next();
		pigLatin = pigLatin(word);
		
		System.out.println("Pig latin: " + pigLatin);
		
		
		System.out.println("Test 'leapYear'");
		System.out.println("Enter year: ");
		
		year = input.nextInt();
		result3 = isLeapYear(year);
		
		if (result3 == true) {
			System.out.println(year + " is a leap year.");
		}
		else {
			System.out.println(year + " is not a leap year.");
		}
		
		
		double [][]a ={{1.0,2.0,3.0,4.0}};
		double [] result4 = matrixStats(a);
		System.out.println("Smallest: " + result4[0]);
		System.out.println("Largest: " + result4[1]);
		System.out.println("Total: " + result4[2]);
		System.out.println("Average: "+ result4[3]);
		
		
		
	}
	/**
     * Determines if s is a palindrome. Ignores case, spaces, digits, and
     * punctuation in the string parameter s.
     *
     * @param s
     *            a string
     * @return true if s is a palindrome, false otherwise
     */
		public static boolean isPalindrome(final String s) {

			boolean result = true;
			char [] charArray = new char[s.length()];
			
			for (int i = 0; i < s.length() ; i++) {
				charArray[i] = s.charAt(s.length() - i - 1);
			}
			for(int i = 0; i < s.length(); i++) {
				if (charArray[i] != s.charAt(i)){
					result = false;
				}
								
			}
			return result;
		}
		
		/**
	     * Determines if name is a valid Java variable name. Variables names must
	     * start with a letter or an underscore, but cannot be an underscore alone.
	     * The rest of the variable name may consist of letters, numbers and
	     * underscores.
	     *
	     * @param name
	     *            a string to test as a Java variable name
	     * @return true if name is a valid Java variable name, false otherwise
	     */
	    public static boolean isValid(final String name) {
	        boolean result = true;

	        if ((name.length() == 1) || (name == "_")) {
	        	result = false;
	        }
	        if(Character.isDigit(name.charAt(0)) == true){
	        	result = false;
	        }
	        return result;
	    }
	    
	    /**
	     * Converts a word to Pig Latin. The conversion is:
	     * 

      
	    if a word begins with a vowel, add "way" to the end of the word.

	         
	    if the word begins with consonants, move the leading consonants to the
	         end of the word and add "ay" to the end of that. "y" is treated as a
	         consonant if it is the first character in the word, and as a vowel for
	         anywhere else in the word.

	         

	     * Preserve the case of the word - i.e. if the first character of word is
	     * upper-case, then the new first character should also be upper case.
	     *
	     * @param word The string to convert to Pig Latin
	     * @return the Pig Latin version of word
	     */
	    public static String pigLatin(String word) {
			String pigWord = "";
			String consonantCluster = "";
			String vowel = "";
			boolean upper = false;
			if(Character.isUpperCase(word.charAt(0)) == true) {
				word = word.toLowerCase();
				upper = true;
			}
			if ( (word.charAt(0) == 'a') || (word.charAt(0) == 'e') || (word.charAt(0) == 'i') || (word.charAt(0) == 'o') || (word.charAt(0) == 'u') ) {
				pigWord = word + "way";
			}
			else {
				for (int i = 0; i < word.length(); i++) {
					if ( (word.charAt(i) != 'a') && (word.charAt(i) != 'e') && (word.charAt(i) != 'i') && (word.charAt(i) != 'o') && (word.charAt(i) != 'u') && (word.charAt(i) != 'y')) {
						consonantCluster += word.charAt(i);
					}
					else {
						vowel += word.charAt(i);
					}
						
				}
				if(upper == true) {
					pigWord += (vowel.substring(0,1).toUpperCase() + consonantCluster + "ay");
				}
				else {
					pigWord += (vowel + consonantCluster + "ay");
				}
				
				
			}
			
			return pigWord;
		}
	    
	    /**
	     * Determines whether or not a year is a leap year.
	     *
	     * @param year
	     *            The year to test (int > 0)
	     * @return true if year is a leap year, false otherwise.
	     */
	    public static boolean isLeapYear(final int year) {
	        boolean result = true;
	        if (year % 4 != 0) {
	        	result = false;
	        }
	        else if (year % 100 == 0) {
	        	result = false;
	        }
	        return result;
	    }
	    
	    
	    /**
	     * Determines the smallest, largest, total, and average of the values in the 2D
	     * list a. You may assume there is at least one value in a and that a is a
	     * square matrix - i.e. the number of columns per row is the same. a must be
	     * unchanged.
	     *
	     * @param a - a 2D list of numbers (2D list of double)
	     *
	     * @return a list of four double values containing the smallest number in a,the
	     *         largest number in a, the total of all numbers in a, and the average
	     *         of all numbers in a, in that order.
	     */
	    public static double[] matrixStats(double[][] a) {
	        double result[] = new double [4];
	        result[0] = a[0][0];
	        result[1] = a[0][0];
	        result[2] = 0;
	        
	        for(int i = 0; i < a.length; i++) {
	        	for(int k = 0; k < a[0].length; k++) {
	        		
	        		if(a[i][k] < result[0]) {
	        			result[0] = a[i][k];
	        		}
	        		if(a[i][k] > result[1]) {
	        			result[1] = a[i][k];
	        		}
	        		
	        		result[2] += a[i][k];
	        	}
	        }
	        result[3] = (result[2] / (a.length * a[0].length));
	        
	        return result;
	    }
	    
	    
}
