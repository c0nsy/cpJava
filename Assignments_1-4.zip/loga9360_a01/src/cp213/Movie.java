package cp213;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Movie class definition.
 *
 * @author David Brown
 * @version 2020-10-01
 */
public class Movie implements Comparable<Movie> {

    // Constants
    public static final int FIRST_YEAR = 1888;
    public static final String[] GENRES = { "science fiction", "fantasy",
	    "drama", "romance", "comedy", "zombie", "action", "historical",
	    "horror", "war" };
    public static final int MAX_RATING = 10;
    public static final int MIN_RATING = 0;

    /**
     * Converts a string of the form "2,3,6" to an array of Integer objects, [2,
     * 3, 6]. Used when reading Movie objects from a file.
     *
     * @param string
     *            The string to convert to an array.
     * @return The array version of string.
     */
    public static Integer[] genresStringToList(final String string) {
	final ArrayList<Integer> genresList = new ArrayList<>();

	char[] strArr = string.toCharArray();
    Character[] chrArr = new Character[strArr.length];
    for(int i = 0;i<strArr.length; i++) 
    {
        chrArr[i]=strArr[i];
        if(Character.isDigit(chrArr[i])) 
        {
            genresList.add(Character.getNumericValue(chrArr[i]));
        }
    }

	// Convert arraylist to an array of Integer.
	return genresList.toArray(new Integer[1]);
    }

    /**
     * Testing.
     *
     * @param args
     *            Unused.
     */
    public static void main(final String[] args) {
	// Movie testing
    	Integer[] genres = {0,3};
    	String title = "Pirate";
    	double rating = 6.9;
    	int year = 1969;
    	String director = "Leo";
    	Movie pulpFiction = new Movie(title,year,director,rating,genres);
    	System.out.println(Movie.menu());
    	System.out.println(pulpFiction.toString());
    	
    	
    }

    /**
     * Returns a string of all genres in the Movie.GENRES list. Use for input
     * menus. Formatted as " 3: romance"
     *
     * @return the genres.
     */
    public static String menu() {
    	
    	String movieList = "";
    	int i = 1;
    	for (String s: GENRES) {
    		movieList += i +". " + s +"\n";
    		i++;
    	}
    	return movieList;
    }

    // Attributes
    private String director = "";
    private Integer[] genres = null;
    private double rating = 0;
    private String title = "";
    private int year = 0;

    /**
     * Instantiates a Movie object.
     *
     * @param title
     *            movie title
     * @param year
     *            year of release
     * @param director
     *            name of director
     * @param rating
     *            rating of 1 - 10 from IMDB
     * @param genres
     *            numbers representing movie genres list
     */
    public Movie(final String title, final int year, final String director,
	    final double rating, final Integer[] genres) {

    this.title = title;
    this.year = year;
    this.director = director;
    this.rating = rating;
    this.genres = genres;
    

    }

    /*
     * (non-Javadoc) Compares this Movie against that Movie. Returns -1 if this Movie
     * comes before that Movie, 1 if this Movie comes after that Movie, and 0 if
     * the two Movies are the same.
     * 
     * Movies are compared first by title, then by year.
     *
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(final Movie that) {

    	int i = 1;
    	if (this.title.equals(that.getTitle()))
    	{
    		if (this.year == that.getYear())
    		{
    			i = 0;
    		}
    		else if (this.year > that.getYear())
    		{
    			i = -1;
    		}
    	}
    	else
    	{
    		if (this.year == that.getYear())
    		{
    			i = 0;
    		}
    		else if (this.year > that.getYear())
    		{
    			i = -1;
    		} 
    	}
    	
    	return i;

    }

    /**
     * Converts a list of genre integers to a string of genre names.
     *
     * @return comma delimited string of genre names based upon the current
     *         movie object's integer genres list. e.g.: [0, 2] returns "science
     *         fiction, drama"
     */
    public String genresListToNames() {

    // your code here
    String str = "";
    
    for(int i = 0; i < this.genres.length - 1; i++)
    {
    	str += GENRES[this.genres[i]] + ", ";
    }
    str += GENRES[this.genres[this.genres.length - 1]];
    return str;
    }

    /**
     * Director getter.
     *
     * @return the director
     */
    public String getDirector() {
	return this.director;
    }

    /**
     * Genres getter.
     *
     * @return the genres list
     */
    public Integer[] getGenres() {
	return this.genres;
    }

    /**
     * Rating getter.
     *
     * @return the rating
     */
    public double getRating() {
	return this.rating;
    }

    /**
     * Title getter.
     *
     * @return the title
     */
    public String getTitle() {
	return this.title;
    }

    /**
     * Year getter.
     *
     * @return the year
     */
    public int getYear() {
	return this.year;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
	int hash = 0;

	for (int i = 0; i < this.title.length(); i++) {
	    hash += this.title.charAt(i);
	}
	hash *= this.year;
	return hash;
    }

    /**
     * Creates a formatted string of Movie key data in the format "title, year".
     * Ex: "Zulu, 1964".
     *
     * @return a Movie key as a string
     */
    public String key() {
	return String.format("%s, %d", this.title, this.year);
    }

    /**
     * Director setter.
     *
     * @param director
     *            the new director value
     */
    public void setDirector(final String director) {
	this.director = director;
    }

    /**
     * Rating setter.
     *
     * @param rating
     *            the new rating
     */
    public void setRating(final double rating) {
	this.rating = rating;
    }

    /**
	 * Genres setter.
	 *
	 * @param genres
	 *            the new list of numeric genres
	 */
	public void setGenres(final Integer[] genres) {
	this.genres = genres;
	}

	/**
     * Title setter.
     *
     * @param title
     *            the new title
     */
    public void setTitle(final String title) {
	this.title = title;
    }

    /**
     * Year setter.
     *
     * @param year
     *            the new year
     */
    public void setYear(final int year) {
	this.year = year;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString() Creates a formatted string of movie
     * data.
     */
    @Override
    public String toString() {
    	
    	return ("Title: " + getTitle() + "\n" + "Year: " + getYear() + "\n" +
    	"Director: " + getDirector() + "\n" + "Rating: " + getRating() + "\n" + "Genres: " + genresListToNames());
    }

    /**
     * Writes a single line of movie data to an open file in the format
     * title|year|director|rating|codes
     *
     * @param ps
     *            output printstream
     */
    public void write(final PrintStream ps) {

    	ps.print(this.title+"|");
        ps.print(this.year+"|");
        ps.print(this.director+"|");
        ps.print(this.rating+"|");
        ps.print(genresListToNames());

    }

    /**
     * Converts a genres list of the form [2,3,7] to a string "2,3,7" for
     * writing Movie data to a file.
     *
     * @return the genres list string
     */
    private String genresListToString() {

    	String genres = "";
    	
    	for (int i = 0; i < this.genres.length - 1; i++)
    	{
    		genres += this.genres[i] + ", ";
    	}
    	genres += this.genres[this.genres.length-1];
        return genres;

    }

}
