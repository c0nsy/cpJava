package cp213;

import java.util.ArrayList;

/**
 * A simple linked list structure of <code>Node T</code> objects. Only the
 * <code>T</code> data contained in the stack is visible through the standard
 * list methods. Extends the <code>SingleLink</code> class, which already
 * defines the head node, length, iterator, and toArray.
 *
 * @author David Brown
 * @version 2020-10-16
 * @param <T> this SingleList data type.
 */
public class SingleList<T extends Comparable<T>> extends SingleLink<T> {

	// Pointer to the rear of the queue.
	private SingleNode<T> rear = null;

	/**
	 * Searches for the first occurrence of key in this SingleList. Private helper
	 * methods - used only by other ADT methods.
	 *
	 * @param key The value to look for.
	 * @return A pointer to the node previous to the node containing key.
	 */
	private SingleNode<T> linearSearch(final T key) {

		
		SingleNode<T> current = this.head;
		if (this.head.getValue() == key) 
		{
			current = null;
		} 
		else 
		{
			if (this.head.getNext().getValue() == key) 
			{
				current = this.head;
			} 
			else 
			{
				while (current.getNext().getValue() != key)
				{
					current = current.getNext();
				}
			}
		}
		return current;
	}

	/**
	 * A helper method to move the front node of the SingleList source to this
	 * SingleList.
	 *
	 * @param source The list to move the front of.
	 */
	private void moveFront(final SingleList<T> source) {

		final SingleNode<T> node = source.head;
		source.head = source.head.getNext();
		node.setNext(null);

		if (source.head == null) 
		{
			source.rear = null;
		}
		if (this.head == null) 
		{
			this.head = node;
		} 
		else 
		{
			this.rear.setNext(node);
		}
		this.rear = node;
		source.length--;
		this.length++;
	}

	/**
	 * Appends data to the end of this SingleList.
	 *
	 * @param data The data to append.
	 */
	public void append(final T data) {

		SingleNode<T> next = new SingleNode<T>(data, null);
		if (this.isEmpty()) {
			this.head = new SingleNode<T>(data, null);
			
		} 
		else 
		{
			SingleNode<T> current = this.head;
			while (current.getNext() != null) 
			{
				current = current.getNext();
			}
			current.setNext(next);
		}
		this.length = this.length+  1;
	}

	/**
	 * Removes duplicates from this SingleList. The list contains one and only one
	 * of each value formerly present in this SingleList. The first occurrence of
	 * each value is preserved.
	 */
	public void clean() {

		ArrayList<T> array = new ArrayList<T>();
		ArrayList<T> arrayCleaned = new ArrayList<T>();
		while (this.head != null) {
			T info = this.removeFront();
			array.add(info);
		}
		for (int i = 0; i < array.size(); i++) 
		{
			if (!arrayCleaned.contains(array.get(i))) 
			{
				arrayCleaned.add(array.get(i));
			}
		}
		for (int i = 0; i < arrayCleaned.size(); i++) 
		{
			this.append(arrayCleaned.get(i));
		}
	}

	/**
	 * Combines contents of two lists into a third. Values are alternated from the
	 * origin lists into this SingleList. The origin lists are empty when finished.
	 * NOTE: data must not be moved, only nodes.
	 *
	 * @param left  The first list to combine with this SingleList.
	 * @param right The second list to combine with this SingleList.
	 */
	public void combine(final SingleList<T> left, final SingleList<T> right) {


		while (!left.isEmpty() || !right.isEmpty()) 
		{
			this.moveFront(left);
			this.moveFront(right);
			if (left.isEmpty() && (right.isEmpty() == false)) 
			{
				this.moveFront(right);
			} 
			else if (right.isEmpty() && (left.isEmpty() == false)) 
			{
				this.moveFront(left);
			}
		}
	}

	/**
	 * Determines if this SingleList contains key.
	 *
	 * @param key The key value to look for.
	 * @return true if key is in this SingleList, false otherwise.
	 */
	public boolean contains(final T key) {

		SingleNode<T> currentNode = this.head;
		boolean returnBool = false;
		if (currentNode.getValue().equals(key)) {
			returnBool = true;
		} else 
		{
			while (currentNode.getNext() != null && returnBool == false)
			{
				currentNode = currentNode.getNext();
				if (currentNode.getValue().equals(key)) 
				{
					returnBool = true;
				}
			}
		}
		return returnBool;
	}

	/**
	 * Finds the number of times key appears in list.
	 *
	 * @param key The value to look for.
	 * @return The number of times key appears in this SingleList.
	 */
	public int count(final T key) {
		int num = 0;
		SingleNode<T> currentNode = this.head;

		while (currentNode != null) {
			if (currentNode.getValue().compareTo(key) == 0) {
				num++;
			}
			currentNode = currentNode.getNext();
		}
		return num;
	}

	/**
	 * Finds and returns the value in list that matches key.
	 *
	 * @param key The value to search for.
	 * @return The value that matches key, null otherwise.
	 */
	public T find(final T key) {
		T info = null;

		if (this.length > 0) 
		{
			final SingleNode<T> prev = this.linearSearch(key);

			if (prev == null) 
			{
				info = this.head.getValue();
				
			} else if (prev.getNext() != null) 
			{
				info = prev.getNext().getValue();
			}
		}
		return info;
	}

	/**
	 * Get the nth item in this SingleList.
	 *
	 * @param n The index of the item to return.
	 * @return The nth item in this SingleList.
	 * @throws ArrayIndexOutOfBoundsException if n is not a valid index.
	 */
	public T get(final int n) throws ArrayIndexOutOfBoundsException {

		int count = 0;
		SingleNode<T> currentNode = this.head;
		
		while (count < n) 
		{
			currentNode = currentNode.getNext();
			count += 1;
		}
		
		return currentNode.getValue();
	}

	/**
	 * Determines whether two lists are identical.
	 *
	 * @param source The list to compare against this SingleList.
	 * @return true if this SingleList contains the same values in the same order as
	 *         source, false otherwise.
	 */
	public boolean identical(final SingleList<T> source) {

		boolean same = true;
		SingleNode<T> curr = this.head;
		SingleNode<T> newNode = source.head;
		if (this.length == source.length) {
			same = true;
		} else {
			same = false;
		}
		while (same == true && curr != null) 
		{
			if (newNode.getValue().equals(curr.getValue())) 
			{
				same = true;
			} 
			else
			{
				same = false;
			}
			newNode = newNode.getNext();
			curr = curr.getNext();
		}
		return same;
	}

	/**
	 * Finds the first location of a value by key in this SingleList.
	 *
	 * @param key The value to search for.
	 * @return The index of key in this SingleList, -1 otherwise.
	 */
	public int index(final T key) {


		int count = 0;
		SingleNode<T> curr = this.head;
		while (curr != null && curr.getValue() != key) 
		{
			count += 1;
			curr = curr.getNext();
		}
		return count;
	}

	/**
	 * Inserts data into this SingleList at index i. If i greater than the length of
	 * this SingleList, append value to the end of this SingleList.
	 *
	 * @param i    The index to insert the new value at.
	 * @param data The new value to insert into this SingleList.
	 */
	public void insert(int i, final T data) {

		if (i > this.length) 
		{
			this.append(data);
		} else 
		{
			int count = 0;
			SingleNode<T> curr = this.head;
			while (count < i) 
			{
				curr = curr.getNext();
				count += 1;
			}
			curr.setNext(new SingleNode<T>(data, curr.getNext()));
		}
	}

	/**
	 * Inserts data into the front of this SingleList.
	 *
	 * @param data The value to insert into the front of this SingleList.
	 */
	public void insertFront(final T data) {

		SingleNode<T> nextNode = new SingleNode<T>(data, null);
		if (this.isEmpty())
		{
			this.head = new SingleNode<T>(data, null);
		} else 
		{
			SingleNode<T> curr = this.head;
			while (curr.getNext() != null) 
			{
				curr = curr.getNext();
			}
			curr.setNext(nextNode);
		}
		this.length = this.length +  1;

	}

	/**
	 * Finds the maximum value in this SingleList.
	 *
	 * @return The maximum value.
	 */
	public T max() {

		T maximum = this.head.getValue();
        SingleNode<T> node = this.head;
        while (node != null) 
        {
            int temp = maximum.compareTo(node.getValue());
            if (temp < 0)
            {
                maximum = node.getValue();
            }
            node = node.getNext();
        }
        return maximum;
	}

	/**
	 * Finds the minimum value in this SingleList.
	 *
	 * @return The minimum value.
	 */
	public T min() {

		T minimum = this.head.getValue();
        SingleNode<T> node = this.head;
        while (node != null) {
            int temp = minimum.compareTo(node.getValue());
            if (temp > 0) {
                minimum = node.getValue();
            }
            node = node.getNext();
        }
        return minimum;
	}

	/**
	 * Finds, removes, and returns the value in this SingleList that matches key.
	 *
	 * @param key The value to search for.
	 * @return The value matching key, null otherwise.
	 */
	public T remove(final T key) {

		SingleNode<T> prev = this.linearSearch(key);
		T info = null;
		if (prev == null) {
			info = this.head.getValue();
			this.head = this.head.getNext();
		} 
		else 
		{
			SingleNode<T> curr = this.head;
			while (curr.getValue() != key) 
			{
				curr = curr.getNext();
			}
			info = curr.getValue();
			curr = curr.getNext();
			prev.setNext(curr);
		}
		this.length = this.length - 1;
		return info;

	}

	/**
	 * Removes the value at the front of this SingleList.
	 *
	 * @return The value at the front of this SingleList.
	 */
	public T removeFront() {

		final SingleNode<T> frontNode = this.head;
		this.head = this.head.getNext();
		frontNode.setNext(null);
		this.length = this.length -  1;
		return frontNode.getValue();
	}

	/**
	 * Reverses the order of the values in this SingleList.
	 */
	public void reverse() {
		SingleNode<T> newHead = null;
		SingleNode<T> tempNode = null;

		while (this.head != null)
		{
			
			tempNode = this.head.getNext();
			this.head.setNext(newHead);
			newHead = this.head;
			this.head = tempNode;
			
		}
		this.head = newHead;
		return;
	}

	/**
	 * Splits the contents of this SingleList into the left and right SingleLists.
	 * Moves nodes only - does not move data or call the high-level methods insert
	 * or remove. this SingleList is empty when done. The first half of this
	 * SingleList is moved to left, and the last half of this SingleList is moved to
	 * right. If the resulting lengths are not the same, left should have one more
	 * item than right.
	 *
	 * @param left  The first SingleList to move nodes to.
	 * @param right The second SingleList to move nodes to.
	 */
	public void split(final SingleList<T> left, final SingleList<T> right) {


		int count = 0;
		while (count < (this.length / 2)) {
			T info = this.removeFront();
			left.append(info);
			count += 1;
		}
		while (!this.isEmpty())
		{
			T info = this.removeFront();
			right.append(info);
		}
	}

	/**
	 * Splits the contents of this SingleList into the left and right SingleLists.
	 * Moves nodes only - does not move data or call the high-level methods insert
	 * or remove. this SingleList is empty when done. Nodes are moved alternately
	 * from this SingleList to left and right.
	 *
	 * @param left  The first SingleList to move nodes to.
	 * @param right The second SingleList to move nodes to.
	 */
	public void splitAlternate(final SingleList<T> left, final SingleList<T> right) {

		while (!this.isEmpty()) 
		{
			if (this.length != 0) 
			{
				if (left.length == 0) 
				{
					left.head = this.head;
					left.rear = this.head;
					this.head = this.head.getNext();
					left.head.setNext(null);
				} 
				else 
				{
					SingleNode<T> temp = this.head;
					left.rear.setNext(this.head);
					left.rear = this.head;
					this.head = this.head.getNext();
					temp.setNext(null);
				}
				left.length += 1;
				this.length -= 1;
			}
			if (this.length != 0) 
			{
				if (right.length == 0) 
				{
					right.head = this.head;
					right.rear = this.head;
					this.head = this.head.getNext();
					right.head.setNext(null);
				} 
				else 
				{
					SingleNode<T> temp = this.head;
					right.rear.setNext(this.head);
					right.rear = this.head;
					this.head = this.head.getNext();
					temp.setNext(null);
				}
				right.length += 1;
				this.length -= 1;
			}
		}
	}

	/**
	 * Creates a union of two other SingleLists into this SingleList. Copies data to
	 * this list. left and right SingleLists are unchanged.
	 *
	 * @param left  The first SingleList to create a union from.
	 * @param right The second SingleList to create a union from.
	 */
	public void union(final SingleList<T> left, final SingleList<T> right) {

		ArrayList<T> leftNode = new ArrayList<T>();
		ArrayList<T> rightNode = new ArrayList<T>();
		for (int i = 0; i < left.length; i++) {
			leftNode.add(left.get(i));
		}
		for (int i = 0; i < right.length; i++) {
			rightNode.add(right.get(i));
		}
		for (int i = 0; i < rightNode.size(); i++) {
			if (leftNode.contains(rightNode.indexOf(i))) {
				this.append(rightNode.get(i));
				this.length += 1;
			}
		}
	}
}